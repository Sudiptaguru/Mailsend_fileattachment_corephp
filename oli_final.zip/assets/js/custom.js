$(document).ready(function() {
    if ($.cookie("disclaimer") == null) {
        $('#bottom_modal').modal('show');
        $.cookie("disclaimer", "1", { expires: 30 });
    }

    setTimeout(function() {
        $('#bottom_modal').modal('hide');
    }, 3000);
});

/*$('#overlay').modal('show');*/
